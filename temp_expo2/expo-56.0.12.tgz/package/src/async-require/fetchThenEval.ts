export { fetchThenEvalAsync } from './fetchThenEvalJs';
